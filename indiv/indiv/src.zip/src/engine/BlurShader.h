#pragma once
#include <glad/glad.h>

// Fullscreen triangle covering NDC [−1,+1]
static const float kQuadVerts[] = {
    -1.f, -1.f,   1.f, -1.f,   1.f,  1.f,
    -1.f, -1.f,   1.f,  1.f,  -1.f,  1.f
};

static const char* kBlurVertSrc = R"(
#version 330 core
layout(location = 0) in vec2 aPos;
out vec2 vUV;
void main() {
    vUV = aPos * 0.5 + 0.5;            // NDC → UV
    gl_Position = vec4(aPos, 0.0, 1.0);
}
)";

static const char* kBlurFragSrc = R"(
#version 330 core
out vec4 FragColor;
in vec2 vUV;
uniform sampler2D uColorTex;
uniform sampler2D uVelocityTex;
uniform vec2  uScreenSize;   // e.g. (1280, 720)
uniform int   uSamples;      // samples per direction
uniform float uStrength;     // velocity multiplier (~40)

void main()
{
    vec2 vel_ndc = texture(uVelocityTex, vUV).rg;          // raw NDC [-2,2]
    vec2 vel_px  = vel_ndc * uScreenSize * 0.5;            // NDC → pixels
    vel_px      *= uStrength;                               // boost
    float mag    = length(vel_px);
    if (mag > 80.0) vel_px *= 80.0 / mag;                    // clamp max blur
    vec2 vel_uv  = vel_px / uScreenSize;                    // pixels → UV

    int N = max(uSamples, 1);
    float totalWeight = 1.0;
    vec4 result = texture(uColorTex, vUV);                  // center

    for (int i = 1; i <= N; ++i)
    {
        float t = float(i) / float(N);
        float w = exp(-t * t * 0.5);                        // mild Gaussian → wide blur
        vec2 off = vel_uv * t;
        result += texture(uColorTex, vUV - off) * w;
        result += texture(uColorTex, vUV + off) * w;
        totalWeight += w * 2.0;
    }
    FragColor = result / totalWeight;
}
)";
